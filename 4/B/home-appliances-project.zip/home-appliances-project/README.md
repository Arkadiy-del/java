# Home Appliances Console Application

Учебный проект на Java по теме: **Домашние электроприборы**.

## Условие

Домашние электроприборы. Определить иерархию электроприборов.
Включить некоторые в розетку. Подсчитать потребляемую мощность.
Провести сортировку приборов в квартире на основе мощности.
Найти прибор в квартире, соответствующий заданному диапазону параметров.

## Что реализовано

- ООП: классы, наследование, полиморфизм, инкапсуляция.
- Пакеты:
  - `by.epam.appliances.entity` — сущности электроприборов.
  - `by.epam.appliances.service` — логика работы с квартирой и загрузкой данных.
  - `by.epam.appliances` — главный класс приложения.
- Минимальное консольное меню.
- Загрузка начальных данных из файла `src/main/resources/appliances.txt`.
- Методы `equals()`, `hashCode()`, `toString()` переопределены для классов.

## Иерархия классов

```text
ElectricalAppliance
 ├── KitchenAppliance
 │    ├── Refrigerator
 │    └── Kettle
 ├── Television
 ├── VacuumCleaner
 └── Iron
```

Наследование применено только там, где оно логически оправдано:

- `Refrigerator`, `Kettle`, `Television`, `VacuumCleaner`, `Iron` являются электроприборами.
- `Refrigerator` и `Kettle` дополнительно являются кухонными электроприборами.

## Как запустить через javac

Из корня проекта выполните:

```bash
javac -encoding UTF-8 -d out $(find src/main/java -name "*.java")
java -cp out by.epam.appliances.Main
```

На Windows можно выполнить:

```bat
dir /s /b src\main\java\*.java > sources.txt
javac -encoding UTF-8 -d out @sources.txt
java -cp out by.epam.appliances.Main
```

## Как запустить через Maven

```bash
mvn compile exec:java
```

## Формат файла с приборами

Файл: `src/main/resources/appliances.txt`

Формат строки:

```text
TYPE;name;power;location;parameter
```

Пример:

```text
REFRIGERATOR;Холодильник Samsung;180;Кухня;320
KETTLE;Электрочайник Tefal;2200;Кухня;1.7
TELEVISION;Телевизор LG;120;Гостиная;43
VACUUM_CLEANER;Пылесос Philips;1600;Кладовая;3.0
IRON;Утюг Bosch;2400;Спальня;true
```

## Меню программы

```text
1. Показать все приборы
2. Включить прибор в розетку
3. Выключить прибор из розетки
4. Подсчитать потребляемую мощность
5. Отсортировать приборы по мощности
6. Найти приборы по диапазону мощности
0. Выход
```
