package by.epam.appliances.service;

import by.epam.appliances.entity.ElectricalAppliance;
import by.epam.appliances.entity.Iron;
import by.epam.appliances.entity.Kettle;
import by.epam.appliances.entity.Refrigerator;
import by.epam.appliances.entity.Television;
import by.epam.appliances.entity.VacuumCleaner;

public final class ApplianceFactory {
    private ApplianceFactory() {
    }

    public static ElectricalAppliance createFromLine(String line) {
        String[] parts = line.split(";");

        if (parts.length != 5) {
            throw new IllegalArgumentException("Некорректная строка файла: " + line);
        }

        String type = parts[0].trim().toUpperCase();
        String name = parts[1].trim();
        int power = Integer.parseInt(parts[2].trim());
        String location = parts[3].trim();
        String parameter = parts[4].trim();

        switch (type) {
            case "REFRIGERATOR":
                return new Refrigerator(name, power, location, Integer.parseInt(parameter));
            case "KETTLE":
                return new Kettle(name, power, location, Double.parseDouble(parameter));
            case "TELEVISION":
                return new Television(name, power, location, Integer.parseInt(parameter));
            case "VACUUM_CLEANER":
                return new VacuumCleaner(name, power, location, Double.parseDouble(parameter));
            case "IRON":
                return new Iron(name, power, location, Boolean.parseBoolean(parameter));
            default:
                throw new IllegalArgumentException("Неизвестный тип прибора: " + type);
        }
    }
}
