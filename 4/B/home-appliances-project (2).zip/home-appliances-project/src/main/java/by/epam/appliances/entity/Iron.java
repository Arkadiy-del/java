package by.epam.appliances.entity;

import java.util.Objects;

public class Iron extends ElectricalAppliance {
    private boolean steamMode;

    public Iron() {
    }

    public Iron(String name, int power, String location, boolean steamMode) {
        super(name, power, location);
        this.steamMode = steamMode;
    }

    public boolean isSteamMode() {
        return steamMode;
    }

    public void setSteamMode(boolean steamMode) {
        this.steamMode = steamMode;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof Iron)) {
            return false;
        }
        Iron iron = (Iron) object;
        return steamMode == iron.steamMode;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), steamMode);
    }

    @Override
    public String toString() {
        return "Iron{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() + " W" +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", steamMode=" + steamMode +
                '}';
    }
}
