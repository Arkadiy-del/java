package by.epam.appliances.service;

import by.epam.appliances.entity.ElectricalAppliance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class Apartment {
    private List<ElectricalAppliance> appliances;

    public Apartment() {
        appliances = new ArrayList<>();
    }

    public Apartment(List<ElectricalAppliance> appliances) {
        this.appliances = appliances;
    }

    public void addAppliance(ElectricalAppliance appliance) {
        appliances.add(appliance);
    }

    public void printAppliances() {
        if (appliances.isEmpty()) {
            System.out.println("В квартире нет электроприборов.");
            return;
        }

        for (ElectricalAppliance appliance : appliances) {
            System.out.println(appliance);
        }
    }

    public boolean plugInAppliance(String name) {
        ElectricalAppliance appliance = findByName(name);

        if (appliance == null) {
            return false;
        }

        appliance.plugIn();
        return true;
    }

    public boolean unplugAppliance(String name) {
        ElectricalAppliance appliance = findByName(name);

        if (appliance == null) {
            return false;
        }

        appliance.unplug();
        return true;
    }

    public int calculateCurrentPower() {
        int totalPower = 0;

        for (ElectricalAppliance appliance : appliances) {
            if (appliance.isPluggedIn()) {
                totalPower += appliance.getPower();
            }
        }

        return totalPower;
    }

    public void sortByPower() {
        appliances.sort(Comparator.comparingInt(ElectricalAppliance::getPower));
    }

    public List<ElectricalAppliance> findByPowerRange(int minPower, int maxPower) {
        List<ElectricalAppliance> result = new ArrayList<>();

        for (ElectricalAppliance appliance : appliances) {
            if (appliance.getPower() >= minPower && appliance.getPower() <= maxPower) {
                result.add(appliance);
            }
        }

        return result;
    }

    public ElectricalAppliance findByName(String name) {
        for (ElectricalAppliance appliance : appliances) {
            if (appliance.getName().equalsIgnoreCase(name)) {
                return appliance;
            }
        }

        return null;
    }

    public List<ElectricalAppliance> getAppliances() {
        return appliances;
    }

    public void setAppliances(List<ElectricalAppliance> appliances) {
        this.appliances = appliances;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof Apartment)) {
            return false;
        }
        Apartment apartment = (Apartment) object;
        return Objects.equals(appliances, apartment.appliances);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appliances);
    }

    @Override
    public String toString() {
        return "Apartment{" +
                "appliances=" + appliances +
                '}';
    }
}
