package by.epam.appliances.service;

import by.epam.appliances.entity.ElectricalAppliance;
import by.epam.appliances.entity.Iron;
import by.epam.appliances.entity.Kettle;
import by.epam.appliances.entity.Refrigerator;
import by.epam.appliances.entity.Television;
import by.epam.appliances.entity.VacuumCleaner;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ApplianceInitializer {
    private ApplianceInitializer() {
    }

    public static Apartment loadFromFile(String fileName) throws IOException {
        Apartment apartment = new Apartment();

        try (BufferedReader reader = Files.newBufferedReader(Path.of(fileName), StandardCharsets.UTF_8)) {
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.isBlank() || line.trim().startsWith("#")) {
                    continue;
                }

                ElectricalAppliance appliance = ApplianceFactory.createFromLine(line);
                apartment.addAppliance(appliance);
            }
        }

        return apartment;
    }

    public static Apartment createDefaultApartment() {
        Apartment apartment = new Apartment();

        apartment.addAppliance(new Refrigerator("Холодильник Samsung", 180, "Кухня", 320));
        apartment.addAppliance(new Kettle("Электрочайник Tefal", 2200, "Кухня", 1.7));
        apartment.addAppliance(new Television("Телевизор LG", 120, "Гостиная", 43));
        apartment.addAppliance(new VacuumCleaner("Пылесос Philips", 1600, "Кладовая", 3.0));
        apartment.addAppliance(new Iron("Утюг Bosch", 2400, "Спальня", true));

        apartment.plugInAppliance("Холодильник Samsung");
        apartment.plugInAppliance("Телевизор LG");

        return apartment;
    }
}
