package by.epam.appliances.entity;

import java.util.Objects;

public class VacuumCleaner extends ElectricalAppliance {
    private double dustCollectorVolume;

    public VacuumCleaner() {
    }

    public VacuumCleaner(String name, int power, String location, double dustCollectorVolume) {
        super(name, power, location);
        this.dustCollectorVolume = dustCollectorVolume;
    }

    public double getDustCollectorVolume() {
        return dustCollectorVolume;
    }

    public void setDustCollectorVolume(double dustCollectorVolume) {
        this.dustCollectorVolume = dustCollectorVolume;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof VacuumCleaner)) {
            return false;
        }
        VacuumCleaner that = (VacuumCleaner) object;
        return Double.compare(that.dustCollectorVolume, dustCollectorVolume) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), dustCollectorVolume);
    }

    @Override
    public String toString() {
        return "VacuumCleaner{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() + " W" +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", dustCollectorVolume=" + dustCollectorVolume + " l" +
                '}';
    }
}
