package by.epam.appliances.entity;

import java.util.Objects;

public class Television extends ElectricalAppliance {
    private int screenSize;

    public Television() {
    }

    public Television(String name, int power, String location, int screenSize) {
        super(name, power, location);
        this.screenSize = screenSize;
    }

    public int getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(int screenSize) {
        this.screenSize = screenSize;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof Television)) {
            return false;
        }
        Television that = (Television) object;
        return screenSize == that.screenSize;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), screenSize);
    }

    @Override
    public String toString() {
        return "Television{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() + " W" +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", screenSize=" + screenSize + " inch" +
                '}';
    }
}
