package by.epam.appliances.entity;

import java.util.Objects;

public class Refrigerator extends KitchenAppliance {
    private int volume;

    public Refrigerator() {
    }

    public Refrigerator(String name, int power, String location, int volume) {
        super(name, power, location, false);
        this.volume = volume;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof Refrigerator)) {
            return false;
        }
        Refrigerator that = (Refrigerator) object;
        return volume == that.volume;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), volume);
    }

    @Override
    public String toString() {
        return "Refrigerator{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() + " W" +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", volume=" + volume + " l" +
                '}';
    }
}
