package by.epam.appliances.entity;

import java.util.Objects;

public abstract class ElectricalAppliance {
    private String name;
    private int power;
    private String location;
    private boolean pluggedIn;

    public ElectricalAppliance() {
    }

    public ElectricalAppliance(String name, int power, String location) {
        this.name = name;
        this.power = power;
        this.location = location;
        this.pluggedIn = false;
    }

    public void plugIn() {
        pluggedIn = true;
    }

    public void unplug() {
        pluggedIn = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isPluggedIn() {
        return pluggedIn;
    }

    public void setPluggedIn(boolean pluggedIn) {
        this.pluggedIn = pluggedIn;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof ElectricalAppliance)) {
            return false;
        }
        ElectricalAppliance that = (ElectricalAppliance) object;
        return power == that.power
                && pluggedIn == that.pluggedIn
                && Objects.equals(name, that.name)
                && Objects.equals(location, that.location);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, power, location, pluggedIn);
    }

    @Override
    public String toString() {
        return "ElectricalAppliance{" +
                "name='" + name + '\'' +
                ", power=" + power +
                ", location='" + location + '\'' +
                ", pluggedIn=" + pluggedIn +
                '}';
    }
}
