package by.epam.appliances.entity;

import java.util.Objects;

public class Kettle extends KitchenAppliance {
    private double waterVolume;

    public Kettle() {
    }

    public Kettle(String name, int power, String location, double waterVolume) {
        super(name, power, location, true);
        this.waterVolume = waterVolume;
    }

    public double getWaterVolume() {
        return waterVolume;
    }

    public void setWaterVolume(double waterVolume) {
        this.waterVolume = waterVolume;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof Kettle)) {
            return false;
        }
        Kettle kettle = (Kettle) object;
        return Double.compare(kettle.waterVolume, waterVolume) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), waterVolume);
    }

    @Override
    public String toString() {
        return "Kettle{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() + " W" +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", waterVolume=" + waterVolume + " l" +
                '}';
    }
}
