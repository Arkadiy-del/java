package by.epam.appliances.entity;

import java.util.Objects;

public abstract class KitchenAppliance extends ElectricalAppliance {
    private boolean usedForCooking;

    public KitchenAppliance() {
    }

    public KitchenAppliance(String name, int power, String location, boolean usedForCooking) {
        super(name, power, location);
        this.usedForCooking = usedForCooking;
    }

    public boolean isUsedForCooking() {
        return usedForCooking;
    }

    public void setUsedForCooking(boolean usedForCooking) {
        this.usedForCooking = usedForCooking;
    }

    @Override
    public boolean equals(Object object) {
        if (!super.equals(object)) {
            return false;
        }
        if (!(object instanceof KitchenAppliance)) {
            return false;
        }
        KitchenAppliance that = (KitchenAppliance) object;
        return usedForCooking == that.usedForCooking;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), usedForCooking);
    }

    @Override
    public String toString() {
        return "KitchenAppliance{" +
                "name='" + getName() + '\'' +
                ", power=" + getPower() +
                ", location='" + getLocation() + '\'' +
                ", pluggedIn=" + isPluggedIn() +
                ", usedForCooking=" + usedForCooking +
                '}';
    }
}
